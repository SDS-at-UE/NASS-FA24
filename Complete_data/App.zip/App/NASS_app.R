options(timeout=300)

library(shiny)
library(tidyverse)
library(leaflet)
library(sf)


setwd("C:\\Users\\o_kho\\OneDrive - University of Evansville\\2024_Fall\\Stat300\\NASS\\App")

#######################  Loading the data  #############################


load("states_geometry.rda")  # states_geometry data
states_map2 <- states_geometry %>%
  sf::st_set_crs(4326) %>% 
  sf::st_transform('+proj=longlat +datum=WGS84')

load("corn_county_cencus.rda")
load("corn_county_survey.rda")

# data_new4 <- st_as_sf(corn_county_cencus) %>%
#   sf::st_set_crs(4326) %>% 
#   sf::st_transform('+proj=longlat +datum=WGS84')

layer_county <- unique(corn_county_cencus$county_state)


###################### Setting the color range ##############################


color_pal1 <- colorRampPalette(colors = c("springgreen4", "yellow3"), space = "Lab")(2)

## Make vector of colors for second bin
#color_pal2 <- colorRampPalette(colors = c("yellow3", "orange"), space = "Lab")(5)

## Make vector of colors for third bin
color_pal3 <- colorRampPalette(colors = c("orange", "red3"), space = "Lab")(15)

## Make vector of colors for fourth bin
#color_pal4 <- colorRampPalette(colors = c("red3", "darkred"), space = "Lab")(5)

## Make vector of colors for last bin
color_pal5 <- colorRampPalette(colors = c("darkred", "black"), space = "Lab")(5)

## Combine the five color palettes
color_pal <- c(color_pal1, color_pal3, color_pal5)#, color_pal4, color_pal5)
#color_pal <- c(color_pal1, color_pal2, color_pal3, color_pal4, color_pal5)


################################## Helper functions  #############################

## https://gist.github.com/addiversitas/d2659ff553f702d60105a97fe46261a0

#helper functions for choropleth animation
setShapeStyle <- function( map, data = getMapData(map), layerId,
                           stroke = NULL, color = NULL,
                           weight = NULL, opacity = NULL,
                           fill = NULL, fillColor = NULL,
                           fillOpacity = NULL, dashArray = NULL,
                           smoothFactor = NULL, noClip = NULL, label = NULL,
                           options = NULL){
  
  options <- c(list(layerId = layerId),
               options,
               filterNULL(list(stroke = stroke, color = color,
                               weight = weight, opacity = opacity,
                               fill = fill, fillColor = fillColor,
                               fillOpacity = fillOpacity, dashArray = dashArray,
                               smoothFactor = smoothFactor, noClip = noClip, label = label
               )))
  # evaluate all options
  options <- evalFormula(options, data = data)
  # make them the same length (by building a data.frame)
  options <- do.call(data.frame, c(options, list(stringsAsFactors = FALSE)))
  
  layerId <- options[[1]]
  style <- options[-1] # drop layer column
  
  leaflet::invokeMethod(map, data, "setStyle", "shape", layerId, style);
}

setShapeLabel <- function(map, data = getMapData(map), 
                          layerId,
                          label = NULL,
                          options = NULL){
  options <- c(list(layerId = layerId),
               options,
               filterNULL(list(label = label
               )))
  # evaluate all options
  options <- evalFormula(options, data = data)
  # make them the same length (by building a data.frame)
  options <- do.call(data.frame, c(options, list(stringsAsFactors = FALSE)))
  
  layerId <- options[[1]]
  style <- options[-1] # drop layer column
  
  leaflet::invokeMethod(map, data, "setLabel", "shape", layerId, label);
}

#helper function in JS for choropleth animation
leafletjs <-  tags$head(
  tags$script(HTML('
  
window.LeafletWidget.methods.setStyle = function(category, layerId, style){
  var map = this;
  if (!layerId){
    return;
  } else if (!(typeof(layerId) === "object" && layerId.length)){
    layerId = [layerId];
  }
  style = HTMLWidgets.dataframeToD3(style);
  layerId.forEach(function(d,i){
    var layer = map.layerManager.getLayer(category, d);
    if (layer){
      layer.setStyle(style[i]);
    }
  });
};
window.LeafletWidget.methods.setLabel = function(category, layerId, label){
  var map = this;
  if (!layerId){
    return;
  } else if (!(typeof(layerId) === "object" && layerId.length)){
    layerId = [layerId];
  }
  layerId.forEach(function(d,i){
    var layer = map.layerManager.getLayer(category, d);
    if (layer){
      layer.unbindTooltip();
      layer.bindTooltip(label[i])
    }
  });
};
'
  ))
)
########################################################################
# Valid themes are: cerulean, cosmo, cyborg, darkly, flatly, journal, 
# lumen, paper, readable, sandstone, simplex, slate, spacelab, 
# superhero, united, yeti.

ui <- navbarPage(leafletjs, theme = shinytheme("superhero"),
                title = "Agriculture Data Analysis Portal",
                tabPanel('Crops',
                         #titlePanel("Crops"),
                         fluidRow( column(3,),
                                   column(6,sliderInput(inputId = "dates", "Timeline of Selected Parameter", 
                                                        min = 2002L,
                                                        max = 2022L,
                                                        value = 2002L,
                                                        sep = "",
                                                        #timeFormat = "%m-%d-%Y",
                                                        step = 5,
                                                        animate = animationOptions(interval = 1000),
                                   ),
                                   ),
                                   column(3,)        
                         ),
                         fluidRow(
                           column(3,
                                  selectInput(inputId = "level", "Choose a level", 
                                              c("County", "State"),
                                              selected = "County"),
                                  
                                  selectInput(inputId = "crop", "Choose a crop", 
                                              c("Corn", "Soybean"),
                                              selected = "Corn"),
                                  
                                  selectInput(inputId = "stat", "Choose a STATISTICCAT_DESC", 
                                              c("PRODUCTION", "YIELD", "AREA PLANTED", "AREA HARVESTED", "SALES"),
                                              selected = "AREA HARVESTED"),
                                  
                                  selectInput(inputId = "source", "Choose a SOURCE_DESC", 
                                              c("CENSUS", "SURVEY"),
                                              selected = "CENSUS"),
                                  
                                  selectInput(inputId = "unit", "Choose a UNIT_DESC", 
                                              c("ACRES", "OPERATIONS"),
                                              selected = "ACRES"),
                           ),
                           column(9,
                                  leafletOutput("map_pop")
                           )
                         )
                         
                         
                         )
                )


server <- function(input, output) {
  
  data_new4 <- reactive({
    if(as.character(input$source) == "CENSUS"){
      st_as_sf(corn_county_cencus) %>%
        sf::st_set_crs(4326) %>% 
        sf::st_transform('+proj=longlat +datum=WGS84')
    }else if(as.character(input$source) == "SURVEY"){
      st_as_sf(corn_county_survey) %>%
        sf::st_set_crs(4326) %>% 
        sf::st_transform('+proj=longlat +datum=WGS84')
    }
  })
  
  
  dates <- reactive({
    data_new4() %>% 
      filter(YEAR == as.numeric(input$dates))
  })
  
  reactive_data <-  reactive({
    if(as.character(input$source) == "CENSUS"){
      switch(input$unit,
             ACRES = data_new4()$corn_county_harvest_census_acres,
             OPERATIONS = data_new4()$corn_county_harvest_census_operation
      )
    }else if(as.character(input$source) == "SURVEY"){
      switch(input$unit,
             ACRES = data_new4()$corn_county_harvest_survey_acres
      )
    } 
  })
  
  reactive_stat <- reactive({
    if(as.character(input$source) == "CENSUS"){
      switch(input$unit,
             ACRES = dates()$corn_county_harvest_census_acres,
             OPERATIONS = dates()$corn_county_harvest_census_operation
      )
    }else if(as.character(input$source) == "SURVEY"){
      switch(input$unit,
             ACRES = dates()$corn_county_harvest_survey_acres
      )
    } 
  })
  
  counties <- reactive({
    data_new4()$county_state 
  })
  
  pal_data <- reactive({
    #colorNumeric(palette = color_pal, domain = 0.001:(max(reactive_data(), na.rm = TRUE)+1))
    colorNumeric(palette = color_pal, domain = reactive_data())
  })
  
  popup_msg <- reactive({
    if(as.character(input$source) == "CENSUS"){
      str_c("<strong>", dates()$county_state, #", ", dates()$State,
            "</strong><br /><strong>", dates()$YEAR, "</strong>",
            "<br /> ACRES: ", dates()$corn_county_harvest_census_acres,
            "<br /> OPERATIONS: ", dates()$corn_county_harvest_census_operation)
    }else if(as.character(input$source) == "SURVEY"){
      str_c("<strong>", dates()$county_state, #", ", dates()$State,
            "</strong><br /><strong>", dates()$YEAR, "</strong>",
            "<br /> ACRES: ", dates()$corn_county_harvest_survey_acres)
    } 
    
  })
  
  output$map_pop <- renderLeaflet({
    leaflet(width = "100%",
            options = leafletOptions(zoomSnap = 0,
                                     zoomDelta = 0.25)) %>%
      addProviderTiles(provider = "CartoDB.Positron") %>% 
      setView(lat = 41.550835, lng = -88.100409, zoom = 5) %>% #41.550835, -86.897873
      addPolygons(data = states_map2,#st_transform(states_map2, crs = "+init=epsg:4326"),
                  group = "state",
                  color = "black",
                  fill = FALSE,
                  weight = 3) %>%
      addPolygons(data = st_transform(filter(data_new4(), YEAR == 2002), crs = "+init=epsg:4326"), #filter(data_new4, YEAR == 2002),#
                  layerId = layer_county,
                  color = "white",
                  weight = 1,
                  smoothFactor = 0,
                  fillOpacity = 0.7)
  })
  
  
  
  observe({
    leafletProxy("map_pop", data = dates()) %>% 
      setShapeStyle(layerId = layer_county, 
                    fillColor = ~ suppressWarnings(pal_data()(reactive_stat())))
  })
  
  observe({
    leafletProxy("map_pop", data = dates()) %>%
      setShapeLabel(layerId = layer_county,
                    label = popup_msg())
  })
  
  observe({
    leafletProxy("map_pop") %>% 
      clearControls() %>% 
      addLegend("bottomleft",
                pal = pal_data(),
                values = na.omit(reactive_data()),
                title = str_to_title(str_replace_all(input$unit, "_", " ")),
                na.label = "",
                opacity = 5)
  })
  
  
  
}

# Run the application 
shinyApp(ui = ui, server = server)


