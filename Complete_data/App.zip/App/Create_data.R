library(tidyverse)
library(data.table)
library(sf)

setwd("C:\\Users\\o_kho\\OneDrive - University of Evansville\\2024_Fall\\Stat300\\NASS\\App\\")
load("selected_crop_data.rda")
load("County_geometry.rda")
load("states_geometry.rda")

###############################################
  
crop_data <- selected_crop_data
crop_data <- data.frame(crop_data, county_state = paste0(str_to_title(crop_data$COUNTY_NAME, locale = "en"), " County, ", 
                                     str_to_title(crop_data$STATE_NAME, locale = "en")))

crop_data[crop_data == "(D)"] <- NA
crop_data$VALUE <- as.numeric(gsub(",","",crop_data$VALUE))

#####################################

county_geometry_main <- County_geometry %>% 
  select(county_state, geometry) %>% 
  distinct()
########################################################
corn_county_harvest_survey_acres <- crop_data %>% 
  filter(COMMODITY_DESC == "CORN",
         AGG_LEVEL_DESC == 'COUNTY',
         STATISTICCAT_DESC == "AREA HARVESTED",
         SOURCE_DESC == 'SURVEY',
         UNIT_DESC == "ACRES") %>% 
  select(county_state, YEAR, VALUE) %>% 
  group_by(county_state, YEAR) %>% 
  summarise(corn_county_harvest_survey_acres = sum(VALUE, na.rm=T)) %>% 
  arrange(YEAR)

year <- c()
for(i in c(unique(corn_county_harvest_survey_acres$YEAR))){
  year = c(year, rep(i, dim(county_geometry_main)[1]))
}
county_geo_corn_county_survey <- data.frame(county_state = rep(county_geometry_main$county_state,24),
                                            YEAR = year,
                                            geometry = rep(county_geometry_main$geometry,24))

corn_county_survey <- left_join(county_geo_corn_county_survey,
                                corn_county_harvest_survey_acres,
                                by = c("county_state", "YEAR"))

save(corn_county_survey, file = "corn_county_survey.rda")
##################################################


corn_county_harvest_census_acres <- crop_data %>% 
  filter(COMMODITY_DESC == "CORN",
         AGG_LEVEL_DESC == 'COUNTY',
         STATISTICCAT_DESC == "AREA HARVESTED",
         SOURCE_DESC == 'CENSUS',
         UNIT_DESC == "ACRES") %>% 
  select(county_state, YEAR, VALUE) %>% 
  group_by(county_state, YEAR) %>% 
  summarise(corn_county_harvest_census_acres = sum(VALUE, na.rm=T)) %>% 
  arrange(YEAR)

corn_county_harvest_census_operation <- crop_data %>% 
  filter(COMMODITY_DESC == "CORN",
         AGG_LEVEL_DESC == 'COUNTY',
         STATISTICCAT_DESC == "AREA HARVESTED",
         SOURCE_DESC == 'CENSUS',
         UNIT_DESC == "OPERATIONS") %>% 
  select(county_state, YEAR, VALUE) %>% 
  group_by(county_state, YEAR) %>% 
  summarise(corn_county_harvest_census_operation = sum(VALUE, na.rm=T)) %>% 
  arrange(YEAR)

year <- c()
for(i in unique(corn_county_harvest_census_acres$YEAR)){
  year = c(year, rep(i, dim(county_geometry_main)[1]))
}
county_geo_corn_census <- data.frame(county_state = rep(county_geometry_main$county_state,5),
                                     YEAR = year,
                                     geometry = rep(county_geometry_main$geometry,5))


corn_county_cencus <- reduce(list(county_geo_corn_census,
                                  corn_county_harvest_census_acres,
                                  corn_county_harvest_census_operation), 
                             dplyr::left_join, by = c("county_state", "YEAR"))

save(corn_county_cencus, file = "corn_county_cencus.rda")




